import pandas as pd
import numpy as np
import statsmodels.api as sm
import math
import scipy.stats as stats

def odd_ratio(data):
    features = ['age', 'sex', 'weight', 'Recur', 'SBP', 'CA19.9', 'CRP', 'CEA', 'post.CEA', 'stage', 'smoking', 'Recur_1y', 'post.CA19.9', 'post.CA19.9.binary', 'post.CA19.9.3grp']
    odd_ratio_list = []
    CI_list = []
    pvalue_list = []
    
    for c in features:
        X = data[c]
        y = data['obesity']

        X = sm.add_constant(X)

        model = sm.GLM(y, X, family=sm.families.Poisson()).fit()
        coef = model.params[1]  
        odds_ratio = np.exp(coef)
        CI = model.conf_int().iloc[1]  

        odds_ratio_rounded = np.round(odds_ratio, 3)
        CI = np.round(CI, 3)
        p_value = model.pvalues[1]  

        odd_ratio_list.append(odds_ratio_rounded)
        CI_list.append(CI)
        pvalue_list.append(p_value)

    print('='*60)
    print(f'{"Feature":<25} {"Odds ratio (CI)":<25} {"p-value":<10}')
    print('-'*60)

    for i in range(len(features)):
        feature_name = features[i]
        odds_ratio = odd_ratio_list[i]
        CI_low, CI_high = CI_list[i]
        p_value = round(pvalue_list[i], 3)

        odds_ratio_CI = f'{odds_ratio:.3f} ({CI_low:.3f} - {CI_high:.3f})'

        print(f'{feature_name:<25} {odds_ratio_CI:<25} {p_value:<10}')
    print('='*60)

def make_ttest(data) :
    features = ['age', 'sex', 'weight', 'Recur', 'SBP', 'CA19.9', 'CRP', 'CEA', 'post.CEA', 'stage', 'smoking', 'Recur_1y', 'post.CA19.9', 'post.CA19.9.binary', 'post.CA19.9.3grp']
    t_stat_list = []
    pvalue_list = []

    for c in features:
        X = data[c]
        y = data['obesity']

        t_stat, p_value = stats.ttest_ind(X, y, nan_policy='omit')
        t_stat_list.append(round(t_stat, 3))
        pvalue_list.append(round(p_value, 3))

    print('='*60)
    print(f'{"Feature":<25} {"t-statistic":<15} {"p-value":<5}')
    print('-'*60)

    for i in range(len(features)) :
        print(f'{features[i]:<25} {t_stat_list[i]:<15} {pvalue_list[i]:<5}')

    print('='*60)
