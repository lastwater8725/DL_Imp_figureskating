import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from value import *

# 1. 데이터 읽어오기
data = pd.read_csv('biostat_ex_data.csv')

odd_ratio(data)
make_ttest(data)

features = ['age', 'sex', 'weight', 'Recur', 'OP_date', 'Recur_date', 'SBP', 'CA19.9', 'CRP', 'CEA', 'post.CEA', 'stage', 'smoking', 'Recur_1y', 'post.CA19.9', 'post.CA19.9.binary', 'post.CA19.9.3grp']
X = data[features]
y = data['obesity']

# 데이터 전처리: 범주형 변수 인코딩 (예시로 Label Encoding을 사용)
X = pd.get_dummies(X, drop_first=True)

# 3. 모델 정의 및 학습
model = RandomForestClassifier(max_depth=2, random_state=0)

# 데이터 분할
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# 모델 학습
model.fit(X_train, y_train)

# 4. 성능 확인
y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
report = classification_report(y_test, y_pred)

print(f"Accuracy: {accuracy:.4f}")
print("Classification Report:")
print(report)

# 예측 값과 실제 값 출력 (5개만)
comparison_df = pd.DataFrame({
    'Actual': y_test,
    'Predicted': y_pred
})

print(comparison_df.head(5))
